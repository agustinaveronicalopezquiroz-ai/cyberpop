const nav = document.querySelector('#main-nav');
const menuToggle = document.querySelector('.menu-toggle');
const modalBackdrop = document.querySelector('[data-modal]');
const toast = document.querySelector('.toast');

menuToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('is-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('.main-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    nav.classList.remove('is-open');
    menuToggle?.setAttribute('aria-expanded', 'false');
  });
});

function openModal() {
  modalBackdrop?.classList.remove('is-hidden');
  document.body.style.overflow = 'hidden';
  setTimeout(() => document.querySelector('#email')?.focus(), 50);
}

function closeModal() {
  modalBackdrop?.classList.add('is-hidden');
  document.body.style.overflow = '';
}

document.querySelectorAll('[data-open-modal]').forEach((button) => button.addEventListener('click', openModal));
document.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', closeModal));
modalBackdrop?.addEventListener('click', (event) => {
  if (event.target === modalBackdrop) closeModal();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !modalBackdrop?.classList.contains('is-hidden')) closeModal();
});

let toastTimeout;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('is-visible'), 3000);
}

document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => showToast(button.dataset.toast));
});

document.querySelectorAll('[data-track-play]').forEach((button) => {
  button.addEventListener('click', () => {
    const row = button.closest('.track-row');
    document.querySelectorAll('.track-row').forEach((item) => {
      item.classList.remove('is-playing');
      item.querySelector('[data-track-play]').textContent = '▶';
    });
    row.classList.add('is-playing');
    button.textContent = '●';
    button.setAttribute('aria-label', 'Canción seleccionada');
    showToast(`Marcaste “${row.querySelector('.track-row__copy strong').textContent}” como tu canción del momento ✦`);
  });
});

document.querySelector('#subscribe-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  closeModal();
  showToast('¡Estás dentro! Revisa tu inbox para la bienvenida POP! ✦');
  event.currentTarget.reset();
});

document.querySelector('#shoutout-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const input = event.currentTarget.querySelector('input');
  const value = input.value.trim();
  if (!value) return;
  const wall = document.querySelector('#shoutout-wall');
  const note = document.createElement('span');
  note.textContent = `“${value}” — tú, ahora mismo`;
  wall.prepend(note);
  input.value = '';
  showToast('Shoutout publicado en el muro POP! ✦');
});

const crosswordInputs = [...document.querySelectorAll('.crossword-grid input')];
crosswordInputs.forEach((input) => {
  input.addEventListener('input', () => {
    input.value = input.value.slice(-1).toUpperCase();
    input.classList.remove('is-correct', 'is-wrong');
  });
});

document.querySelector('#check-crossword')?.addEventListener('click', () => {
  let correct = 0;
  let incomplete = 0;
  crosswordInputs.forEach((input) => {
    const value = input.value.toUpperCase();
    input.classList.remove('is-correct', 'is-wrong');
    if (!value) {
      incomplete += 1;
    } else if (value === input.dataset.answer) {
      correct += 1;
      input.classList.add('is-correct');
    } else {
      input.classList.add('is-wrong');
    }
  });
  const status = document.querySelector('#crossword-status');
  if (incomplete) {
    status.textContent = `Vas ${correct}/${crosswordInputs.length}. Aún quedan ${incomplete} casillas vacías.`;
  } else if (correct === crosswordInputs.length) {
    status.textContent = '¡CRUCI COMPLETADO! Tu cerebro acaba de ganar una portada ✦';
    showToast('¡Crucigrama resuelto!');
  } else {
    status.textContent = `${correct}/${crosswordInputs.length} correctas. Las rosas necesitan otra vuelta.`;
  }
});

const anecdoteText = document.querySelector('#anecdote-text');
anecdoteText?.addEventListener('input', () => {
  const counter = document.querySelector('#anecdote-count');
  if (counter) counter.textContent = `${anecdoteText.value.length} / 500`;
});

document.querySelector('#anecdote-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const alias = document.querySelector('#anecdote-alias').value.trim();
  const story = anecdoteText.value.trim();
  if (!alias || !story) return;
  const wall = document.querySelector('#anecdote-wall');
  wall.textContent = `“${story}” — ${alias}`;
  event.currentTarget.reset();
  document.querySelector('#anecdote-count').textContent = '0 / 500';
  showToast('Anécdota recibida: ya está compitiendo por la portada ✦');
});

document.querySelector('#headline-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const selected = event.currentTarget.querySelector('input[name="headline"]:checked');
  if (selected) showToast(`Votaste por: “${selected.value}” ✦`);
});

const loveButton = document.querySelector('#love-button');
const loveScore = document.querySelector('#love-score');
const loveMessage = document.querySelector('#love-message');
const loveFill = document.querySelector('#love-fill');
const loveGauge = document.querySelector('.love-gauge');
const loveEmoji = document.querySelector('#love-emoji');

const loveMessages = [
  { min: 0, emoji: '☁', text: 'Hay química de playlist triste. Empiecen por una canción y cero presión.' },
  { min: 35, emoji: '♡', text: 'Vibe interesante: una conversación larga podría cambiarlo todo.' },
  { min: 60, emoji: '✦', text: 'El algoritmo del universo dice: aquí hay chispa. Invita a un café.' },
  { min: 80, emoji: '💖', text: 'Nivel portada de revista. Disfruten la magia, sin dejar de ser ustedes.' }
];

loveButton?.addEventListener('click', () => {
  const score = Math.floor(Math.random() * 101);
  const match = [...loveMessages].reverse().find((item) => score >= item.min);
  const firstName = document.querySelector('#love-one')?.value.trim();
  const secondName = document.querySelector('#love-two')?.value.trim();
  const pair = firstName && secondName ? `${firstName} + ${secondName}: ` : '';
  loveScore.textContent = `${score}%`;
  loveMessage.textContent = `${pair}${match.text}`;
  loveEmoji.textContent = match.emoji;
  loveFill.style.width = `${score}%`;
  loveGauge.setAttribute('aria-valuenow', String(score));
});

const quizSteps = [...document.querySelectorAll('.quiz-step')];
const quizResult = document.querySelector('.quiz-result');
const progress = document.querySelector('.quiz-progress span');
const scores = { dreamer: 0, icon: 0, maker: 0 };
let currentStep = 0;

const quizResults = {
  dreamer: {
    title: 'ERES LA DREAMER POP!',
    text: 'Tu superpoder es encontrar belleza en los detalles. Hoy: baja el volumen del mundo, arma una playlist lenta y deja que una idea se quede contigo.'
  },
  icon: {
    title: 'ERES EL POP ICON!',
    text: 'Llegas con tu propia luz y no necesitas pedir permiso para usarla. Hoy: ponte ese look, manda ese mensaje y ocupa el centro de tu propia historia.'
  },
  maker: {
    title: 'ERES EL CREATOR POP!',
    text: 'Tu energía se activa cuando haces, mezclas y pruebas. Hoy: empieza algo imperfecto —un look, una nota, un proyecto— y deja que el proceso te sorprenda.'
  }
};

document.querySelectorAll('.quiz-options button').forEach((button) => {
  button.addEventListener('click', () => {
    scores[button.dataset.answer] += 1;
    quizSteps[currentStep].classList.add('is-hidden');
    currentStep += 1;
    if (currentStep < quizSteps.length) {
      quizSteps[currentStep].classList.remove('is-hidden');
      if (progress) {
        const value = ((currentStep + 1) / quizSteps.length) * 100;
        progress.style.width = `${value}%`;
        progress.parentElement.setAttribute('aria-valuenow', String(value));
      }
    } else {
      const winner = Object.keys(scores).sort((a, b) => scores[b] - scores[a])[0];
      quizResult.querySelector('h3').textContent = quizResults[winner].title;
      quizResult.querySelector('p').textContent = quizResults[winner].text;
      quizResult.classList.remove('is-hidden');
      if (progress) {
        progress.style.width = '100%';
        progress.parentElement.setAttribute('aria-valuenow', '100');
      }
    }
  });
});

document.querySelector('[data-reset-quiz]')?.addEventListener('click', () => {
  scores.dreamer = 0;
  scores.icon = 0;
  scores.maker = 0;
  currentStep = 0;
  quizResult.classList.add('is-hidden');
  quizSteps.forEach((step, index) => step.classList.toggle('is-hidden', index !== 0));
  if (progress) {
    progress.style.width = '25%';
    progress.parentElement.setAttribute('aria-valuenow', '25');
  }
});

const sections = [...document.querySelectorAll('main section[id]')];
const navLinks = [...document.querySelectorAll('.main-nav a')];
const sectionToLink = new Map(navLinks.map((link) => [link.getAttribute('href').slice(1), link]));
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    navLinks.forEach((link) => link.classList.remove('is-active'));
    sectionToLink.get(entry.target.id)?.classList.add('is-active');
  });
}, { rootMargin: '-35% 0px -55% 0px', threshold: 0 });
sections.forEach((section) => observer.observe(section));
