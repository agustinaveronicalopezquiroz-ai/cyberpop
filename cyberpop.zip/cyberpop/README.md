# CYBERPOP — Revista digital Y2K

Sitio web estático en español, listo para publicar. CYBERPOP reúne estética de revista pop de los años 2000, música y moda actuales, entrevistas, chismes con contexto, juegos y concursos participativos.

## Archivos

- `index.html` — estructura y contenido de la revista, incluyendo entrevistas, sección de chismes con niveles de verificación, crucigrama interactivo y concursos.
- `styles.css` — diseño responsive, colores, tipografía y componentes visuales.
- `script.js` — menú móvil, modal de suscripción, test POP!, playlist interactiva, medidor de amor aleatorio, crucigrama, concursos, muro de shoutouts y mensajes toast.

## Publicación

No necesita instalación ni build. Sube los tres archivos (`index.html`, `styles.css`, `script.js`) al hosting estático que prefieras:

- Netlify Drop
- GitHub Pages
- Vercel
- Cloudflare Pages
- Cualquier servidor web convencional

La web utiliza Google Fonts y fotografías remotas de Unsplash. La playlist muestra el Top global 2025 de Spotify Wrapped (último ranking anual completo disponible) con enlaces a Spotify; las tendencias de moda 2026 incluyen referencias enlazadas de Vogue y Harper’s Bazaar. Si se necesita una versión completamente autónoma, se pueden reemplazar esas URLs por archivos locales en una carpeta `assets/`.

## Nota editorial

Los nombres de artistas y las secciones son una selección editorial, no una clasificación oficial. Las entrevistas reproducen citas breves o paráfrasis identificadas con enlaces a sus fuentes. La sección de chismes separa hechos confirmados, versiones periodísticas y datos no confirmados para no presentar rumores como hechos. El medidor de amor, el crucigrama y los concursos funcionan localmente en el navegador: las participaciones no se almacenan en un servidor. Los consejos de bienestar son generales y no sustituyen ayuda profesional cuando sea necesaria.
